/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package l04.getandpost;

/**
 *
 * @author LeviPotutschnig
 */
public class L04GetandPost {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       new Webserver();
       new HTTPClient();
    }
    
}
